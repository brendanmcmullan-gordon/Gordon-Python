print(
    """
    B R E N D A N
    R R
    E   E
    N     N
    D       D
    A         A
    N           N    
    """
)
