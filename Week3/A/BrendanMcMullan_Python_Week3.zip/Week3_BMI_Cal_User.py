userWeight = float(input("Enter your weight in kilograms:"))
userHeight = float(input("Enter your height in metres:"))

userBMI = userWeight / userHeight ** 2

print("Your BMI is", userBMI)
