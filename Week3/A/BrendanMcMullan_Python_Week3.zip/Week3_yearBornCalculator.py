age= float(input("Type your age:"))
yearBorn = 0
yearBorn = int(2019 - age)
print("You were born in:", yearBorn)
