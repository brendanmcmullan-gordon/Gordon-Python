age = float(input("Type your age:"))
hours = age * 365 * 24
print("\nYou’re over", hours, "hours old")
