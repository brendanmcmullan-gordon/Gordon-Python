numberMiles = float(input("Enter the number of miles:"))
numberKilometres = numberMiles*1.6

print(numberMiles, "miles = ", numberKilometres, "kilometres")
