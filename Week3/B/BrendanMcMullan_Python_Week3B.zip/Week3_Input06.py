numStr1 = int(input("Please enter a number."))
numStr2 = int(input("Please enter another number."))

print(numStr1, "divided by", numStr2, "=", int(numStr1/numStr2), "remainder", numStr1%numStr2)
