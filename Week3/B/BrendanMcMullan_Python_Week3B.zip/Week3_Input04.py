#Something about doubles?
#Input two real numbers (doubles) from the keyboard and display the difference (subtract) of the two numbers.

numStr1 = int(input("Please enter a number."))
numStr2 = int(input("Please enter another number."))

print(numStr1, "minus", numStr2, "is", numStr1-numStr2)

