print("Melbourne")
# This line was missing a double quote
print("Adelaide")
print("Perth")
# This line had a capitalised Print
print("Sydney")
print("Hobart")
# This line had a misspelled print command
