print("Hello Brendan"+"\n"+"McMullan!")
print("31 Shepherdson Avenue"+"\n"+"Corio")
print("Phone:"+"\n"+"0466569378")
