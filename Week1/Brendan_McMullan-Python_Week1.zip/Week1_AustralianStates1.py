print("Australian Capital Territory"+"\n"+"ACT"+"\n"+"Canberra"+"\n"+"390,800"+"\n")
print("New South Wales"+"\n"+"NSW"+"\n"+"Sydney"+"\n"+"7,618,200"+"\n")
print("Northern Territory"+"\n"+"NT"+"\n"+"Darwin"+"\n"+"244,600"+"\n")
print("Queensland"+"\n"+"Qld"+"\n"+"Brisbane"+"\n"+"4,779,400"+"\n")
print("South Australia"+"\n"+"SA"+"\n"+"Adelaide"+"\n"+"1,698,600"+"\n")
print("Tasmania"+"\n"+"Tas"+"\n"+"Hobart"+"\n"+"516,600"+"\n")
print("Victoria"+"\n"+"Vic"+"\n"+"Melbourne"+"\n"+"5,938,100"+"\n")
print("Western Australia"+"\n"+"WA"+"\n"+"Perth"+"\n"+"2,591,600"+"\n")

