print("Monday"+"\n"+"Tuesday"+"\n"+"Wednesday"+"\n"+"Thursday"+"\n"+"Friday")
print("\n"+"Saturday"+"\n"+"Sunday")
