def calculateSellingPrice(costPrice):
    sellingPrice = costPrice*2
    print("The Cost Price is:", costPrice)
    print("The Selling Price is:", sellingPrice), "\n"

calculateSellingPrice(66)
calculateSellingPrice(3)
calculateSellingPrice(55.5)
calculateSellingPrice(2093.84)
