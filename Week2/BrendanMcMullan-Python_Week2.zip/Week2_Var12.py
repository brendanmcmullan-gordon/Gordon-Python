length = 57
width = 19
area = length*width
print("LENGTH", length, "x", "WIDTH", width, "= AREA", area)
