employeeFirstName = "Fred"
employeeLastName = "Flintstone"
wageRate = 10
hoursWorked = 34
wagesEarned = wageRate * hoursWorked

print("Wages for\n"+employeeFirstName+"\n"+employeeLastName+":")
print("Hourly Rate: $", wageRate, sep="")
print("Hours Worked:", hoursWorked)
print("Weekly Wage: $", wagesEarned, sep="")
