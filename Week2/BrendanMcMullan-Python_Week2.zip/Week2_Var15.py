unitPrice = 45.50
numberPurchased = 11
totalPrice = unitPrice*numberPurchased

print("Unit Price $", unitPrice, sep="")
print("Number bought", numberPurchased)
print("Total Price $", totalPrice, sep="")

