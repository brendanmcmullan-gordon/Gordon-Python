unitPrice = 45
numberPurchased = 11
totalPrice = unitPrice*numberPurchased
print(totalPrice)
