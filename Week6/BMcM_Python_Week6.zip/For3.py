num = 0

for num in range(0, 51, 5):
    print("The current number is", num)
