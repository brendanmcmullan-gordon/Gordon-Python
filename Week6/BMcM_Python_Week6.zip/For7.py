fives = 0
num = 0
for num in range(100, 201, 5):
    print(num)
    fives += num
print("The multiples of 5 between 100 and 200 equal", fives)
