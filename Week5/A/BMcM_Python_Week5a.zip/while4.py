even = 2
evenSum = 0
while (even <= 20):
    evenSum += even
    print(even)
    even += 2
print("All of the even numbers from 2 to 20 =", evenSum)
